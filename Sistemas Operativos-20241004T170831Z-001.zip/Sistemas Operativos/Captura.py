#instalar python -m pip install pillow
from PIL import ImageGrab

screenshot = ImageGrab.grab()

screenshot.save('screenshot.png')

