import socket
import os

def es_ip_valida(ip):
    """Comprueba si la cadena proporcionada tiene un formato de dirección IPv4 válida."""
    try:
        socket.inet_pton(socket.AF_INET, ip)
        return True
    except socket.error:
        return False

def obtener_entrada_usuario(mensaje):
    """Obtiene la entrada del usuario con un mensaje, manejando el comando de salida potencial."""
    while True:
        entrada_usuario = input(mensaje)
        if entrada_usuario.lower() == 'salir':
            exit()
        return entrada_usuario

# Obtener la dirección IP del host (asegúrate de que sea una dirección IPv4 válida)
host = obtener_entrada_usuario("Introduce la dirección IP del servidor (o 'localhost' para local): ")
if host != 'localhost' and not es_ip_valida(host):
    print("Dirección IP no válida. Introduce una dirección IPv4 válida o 'localhost'.")
    exit()

# Obtener el número de puerto (asegúrate de que esté dentro del rango válido)
puerto = int(obtener_entrada_usuario("Introduce el número de puerto del servidor: "))
if puerto < 0 or puerto > 65535:
    print("Número de puerto no válido. Introduce un valor entre 0 y 65535.")
    exit()

# Crear un socket TCP
socket_cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Conectarse al servidor
try:
    socket_cliente.connect((host, puerto))
except ConnectionRefusedError:
    print("Conexión rechazada. El servidor podría estar inactivo o inaccesible.")
    exit()

# Enviar el nombre del archivo
nombre_archivo = obtener_entrada_usuario("Introduce la ruta a la imagen o captura de pantalla (o 'salir' para salir): ")
if nombre_archivo == 'salir':
    exit()

socket_cliente.sendall(nombre_archivo.encode('utf-8'))

# Comprobar si el archivo existe y obtener su tamaño
try:
    tamaño_archivo = os.path.getsize(nombre_archivo)
except FileNotFoundError:
    print("Archivo no encontrado. Introduce una ruta de archivo válida.")
    exit()

# Enviar el tamaño del archivo
socket_cliente.sendall(str(tamaño_archivo).encode('utf-8'))

# Enviar los datos de la imagen
with open(nombre_archivo, 'rb') as archivo:
    bytes_enviados = 0
    while bytes_enviados < tamaño_archivo:
        datos = archivo.read(1024)
        socket_cliente.sendall(datos)
        bytes_enviados += len(datos)

# Recibir confirmación o mensaje de error del servidor (opcional)
# respuesta = socket_cliente.recv(1024).decode('utf-8')
# print(f"Respuesta del servidor: {respuesta}")  # Descomentar para recibir la respuesta

socket_cliente.close()
print("Transferencia de archivo completada.")
