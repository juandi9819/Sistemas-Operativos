import socket
host = "192.168.1.20"  # Kali linux -- ifconfig
port  = 4444

server_socket =  socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server_socket.bind((host, port))

server_socket.listen(1)
print(f"Servidor escuchando en: {host}:{port}")

client_socket , client_adrress = server_socket.accept()
print(f"Conexion establecida desde :{client_adrress}:{client_socket}")

while True:
    data = client_socket.recv(1024)
    if not data:
        break
    print(f"Recibido de Cliente: ,{data.decode('utf-8')}")

client_socket.close()
server_socket.close()
    