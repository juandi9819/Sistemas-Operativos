import * as firebaseController from './firebaseController.js'; // Importa las funciones del controlador

// Configuración de Firebase (con tus credenciales)
const firebaseConfig = {
  apiKey: "AIzaSyBM0AJb83U6n3NqFP1G-XvfeMJ4qV-Upxg",
  authDomain: "pagina-prestada.firebaseapp.com",
  databaseURL: "https://pagina-prestada-default-rtdb.firebaseio.com",
  projectId: "pagina-prestada",
  storageBucket: "pagina-prestada.appspot.com",
  messagingSenderId: "340749068048",
  appId: "1:340749068048:web:eb2a97c9e9cd4dde00e795"
};

firebaseController.inicializarFirebase(firebaseConfig); // Inicializa Firebase en el controlador

// Obtén referencias a los formularios
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const contactForm = document.getElementById("contactForm");

// Manejadores de eventos de los formularios
loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;
  await firebaseController.loginUsuario(email, password); 
});

registerForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const nombre = document.getElementById("register-name").value;
  const email = document.getElementById("register-email").value;
  const password = document.getElementById("register-password").value;
  await firebaseController.registrarUsuario(nombre, email, password);
});

contactForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const nombre = document.getElementById("contact-name").value;
  const telefono = document.getElementById("contact-phone").value;
  const correo = document.getElementById("contact-email").value;
  const mensaje = document.getElementById("contact-message").value;
  await firebaseController.enviarMensajeContacto(nombre, telefono, correo, mensaje);
});
