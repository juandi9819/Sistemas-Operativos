import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.1/firebase-app.js";
import { getDatabase, ref, set } from "https://www.gstatic.com/firebasejs/10.12.1/firebase-database.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.12.1/firebase-auth.js";

// Configuración de Firebase (reemplaza con tus credenciales reales o usa variables de entorno)
const firebaseConfig = {
  // ... tus credenciales de Firebase ...
};

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);
const auth = getAuth();

// Funciones del controlador
export async function loginUsuario(email, password) {
  try {
    await signInWithEmailAndPassword(auth, email, password);
    // Redirige o realiza otras acciones después del inicio de sesión exitoso
  } catch (error) {
    console.error("Error al iniciar sesión:", error);
    // Manejo de errores (mostrar mensaje al usuario, etc.)
  }
}

export async function registrarUsuario(nombre, email, password) {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    await set(ref(database, 'usuarios/' + user.uid), {
      nombre: nombre,
      correo: email,
    });
  } catch (error) {
    console.error("Error al registrar usuario:", error);
    // Manejo de errores
  }
}

export async function enviarMensajeContacto(nombre, telefono, correo, mensaje) {
  try {
    await set(ref(database, 'mensajes/' + Date.now()), { // Usa la fecha como ID único
      nombre,
      telefono,
      correo,
      mensaje
    });
    // Mostrar mensaje de éxito
  } catch (error) {
    console.error("Error al enviar mensaje:", error);
    // Manejo de errores
  }
}
