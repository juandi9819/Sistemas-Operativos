
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.1/firebase-app.js";
  import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.1/firebase-auth.js";
  import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.1/firebase-firestore.js";

  // Your web app's Firebase configuration (Actualizado con tus datos)
  const firebaseConfig = {
    apiKey: "AIzaSyBM0AJb83U6n3NqFP1G-XvfeMJ4qV-Upxg",
    authDomain: "pagina-prestada.firebaseapp.com",
    projectId: "pagina-prestada",
    storageBucket: "pagina-prestada.appspot.com",
    messagingSenderId: "340749068048",
    appId: "1:340749068048:web:eb2a97c9e9cd4dde00e795"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const auth = getAuth(app); // Obtiene la instancia de autenticación
  const db = getFirestore(app); // Obtiene la instancia de Firestore
  
  // Ejemplo de uso
  console.log("Firebase inicializado:", app);

