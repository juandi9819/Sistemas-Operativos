#pip install geocoder
import geocoder
 def obtener_ubicacion():
    ubicacion = geocoder('me')

    print ("ubicacion actual")
    print("Latitud",ubicacion.latlng[0])
    print("Longitud",ubicacion.latlng[1])
    print("Direccion",ubicacion.address)

obtener_ubicacion():
