print("SERIE 1")
def serie1[n]:
    for i in range(n, -4, -1):
        print(i, end=" ")
serie1(5)
print("\n")
print("SERIE 2")
def serie2(n):
    resultado = []
    valor = 1
    for _ in range(n):
        resultado.append(valor)
        valor *= 2
    return resultado
n_numeros2 = 9
serie_resultante2 = serie2(n_numeros2)
print(serie_resultante2)

print("\n")
print("SERIE 3")
def serie3(n):
    serie = []
    valor = 1
    for _ in range(n):
        serie.append(valor)
        if valor % 3 == 0:
            valor += 2
        else:
            valor += 1
    return serie
n_numeros3 = 8
serie_resultante3 = serie3(n_numeros3)
print(serie_resultante3)

print("\n")
print("SERIE 4")
def serie4(n):
    serie = [1]  
    valor_actual = 1
    for i in range(1, n):
        valor_actual += i
        serie.append(valor_actual)
    return serie
n_numeros4 = 9
serie_resultante4 = serie4(n_numeros4)
print(serie_resultante4)

print("\n")
print("SERIE 5 ")
def generar_serie(n):
    serie = [1, 2]  # Comenzamos con los dos primeros números de la serie
    for i in range(2, n):
        if i % 2 == 0:
            # Si el índice es par, calculamos el siguiente número restando el valor anterior
            siguiente_numero = serie[i - 2] - serie[i - 1]
        else:
            # Si el índice es impar, calculamos el siguiente número sumando el valor anterior
            siguiente_numero = serie[i - 2] + serie[i - 1]
        serie.append(siguiente_numero)
    return serie

# Ejemplo: Generar los primeros 9 números de la serie
n_numeros = 9
serie_resultante = generar_serie(n_numeros)
print(f"Los primeros {n_numeros} números de la serie son:")
print(serie_resultante)


