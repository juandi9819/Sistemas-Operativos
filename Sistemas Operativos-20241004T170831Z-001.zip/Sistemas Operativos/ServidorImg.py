import socket
import os

def is_valid_ip(ip):
    """Checks if the provided string is a valid IPv4 address format."""
    try:
        socket.inet_pton(socket.AF_INET, ip)
        return True
    except socket.error:
        return False

def send_image(image_path):
    """Sends an image to the server."""
    try:
        # Validate IP address (optional, uncomment if needed)
        # if not is_valid_ip(host):
        #     print("Invalid IP address. Please enter a valid IPv4 address.")
        #     return

        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((host, port))

        # Check if file exists
        if not os.path.isfile(image_path):
            print(f"File not found: {image_path}")
            return

        # Send file size (optional, consider sending filename instead)
        # file_size = os.path.getsize(image_path)
        # client_socket.sendall(str(file_size).encode('utf-8'))

        with open(image_path, 'rb') as image_file:
            image_data = image_file.read()
            client_socket.sendall(image_data)

    except ConnectionRefusedError:
        print("Connection refused. Check the server's IP address and port.")
    except FileNotFoundError:
        print(f"File not found: {image_path}")
    finally:
        client_socket.close()
        print("Connection closed.")

# Get user input with validation
while True:
    image_path = input("Ingrese la ruta de la imagen para enviar al Servidor o 'exit' para salir: ")
    if image_path.lower() == 'exit':
        exit()
    elif os.path.isfile(image_path):
        send_image(image_path)
        break
    else:
        print(f"Invalid path: {image_path}")
