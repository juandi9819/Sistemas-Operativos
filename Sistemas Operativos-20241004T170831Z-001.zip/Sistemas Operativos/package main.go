package main 

import (
	"fmt"
	"time"
)

func hola(){
	time.Sleep(1*time.Second)
	fmt.Println("Esto es una goroutines")
}

func main() {
	go hola() //Llamada a la función en otra Goroutine
	// La función principal sigue ejecutándose, por lo que aquí se imprime esto:
	fmt.Println("Funcion Principal")
}