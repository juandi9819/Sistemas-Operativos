import time
def es_primo(numero):
  """
  Función que comprueba si un número es primo.

  Parámetros:
    numero: El número a comprobar.

  Retorno:
    True si el número es primo, False si no lo es.
  """
  if numero <= 1:
    return False
  for i in range(2, int(numero**0.5) + 1):
    if numero % i == 0:
      return False
  return True
def main():
  """
  Función principal que calcula los primeros 100.000 números primos y mide el tiempo de ejecución.
  """
  inicio = time.time()
  primos = []
  for i in range(2, 100001):
    if es_primo(i):
      primos.append(i)
  fin = time.time()
  tiempo_ejecucion = fin - inicio
  print(f"Los primeros 100.000 números primos son: {primos}")
  print(f"Tiempo de ejecución: {tiempo_ejecucion:.2f} segundos")

if __name__ == "__main__":
  main()
