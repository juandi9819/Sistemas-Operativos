import socket

host = "192.168.1.20"  # Replace with the server's IP address if necessary
port = 4444

try:
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))

    while True:
        message = input("Ingrese datos para enviar al Servidor o 'exit' para salir: ")
        if message == 'exit':
            break

        client_socket.sendall(message.encode('utf-8'))

except ConnectionRefusedError:
    print("Connection refused. Check the server's IP address and port.")

finally:
    client_socket.close()
    print("Connection closed.")
