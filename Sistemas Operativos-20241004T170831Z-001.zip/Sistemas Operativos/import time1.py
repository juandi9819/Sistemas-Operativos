import time
import concurrent.futures

def es_primo(numero):
  """
  Función que comprueba si un número es primo.

  Parámetros:
    numero: El número a comprobar.

  Retorno:
    True si el número es primo, False si no lo es.
  """
  if numero <= 1:
    return False
  for i in range(2, int(numero**0.5) + 1):
    if numero % i == 0:
      return False
  return True

def main():
  """
  Función principal que calcula los primeros 100.000 números primos y mide el tiempo de ejecución.
  """
  inicio = time.time()
  
  # Crear un "WaitGroup" para controlar la finalización de las tareas
  wg = concurrent.futures.WaitGroup()

  # Crear una lista para almacenar los números primos
  primos = []

  # Crear un pool de "workers" para ejecutar las tareas en paralelo
  with concurrent.futures.ThreadPoolExecutor() as executor:
    for i in range(2, 100001):
      # Iniciar una tarea para calcular si el número es primo
      wg.add(1)
      executor.submit(lambda n: _calcular_primo(n, primos, wg), i)

  # Esperar a que todas las tareas finalicen
  wg.wait()

  fin = time.time()
  tiempo_ejecucion = fin - inicio
  print(f"Los primeros 100.000 números primos son: {primos}")
  print(f"Tiempo de ejecución: {tiempo_ejecucion:.2f} segundos")

def _calcular_primo(numero, primos, wg):
  """
  Función que calcula si un número es primo y lo añade a la lista de números primos.

  Parámetros:
    numero: El número a comprobar.
    primos: La lista donde se almacenarán los números primos.
    wg: El "WaitGroup" para controlar la finalización de las tareas.

  Retorno:
    None.
  """
  if es_primo(numero):
    primos.append(numero)
  wg.done()

if __name__ == "__main__":
  main()
