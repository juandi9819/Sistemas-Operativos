from itertools import islice

def serie():
    a, b = 1, 1
    while True:
        yield a
        a, b = b, a + b

# Imprimir los primeros 10 números de la sucesión
for num in islice(serie(), 7):
    print(num)

print ("Segundo Ejercicio", \n)

numeros = [1, 2, 12, 14, 23, 26, 34, 38, 45, 50, 56]

for numero in numeros:
  print(numero)
