import socket

host = "192.168.1.20" #cliente windows -- ipconfig
port = 4444

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client_socket.connect((host, port)) 

while True:
    message = input("Ingrese datos para enviar el Servidor o 'exit' para salir:  ")
    if message ==  'exit':
        break
    client_socket.sendall(message.encode('utf-8'))

client_socket.close()


